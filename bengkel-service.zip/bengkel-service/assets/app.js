/* BengkelPro Red Edition — progressive enhancement; works without JS. */
(() => {
  'use strict';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => Array.from(root.querySelectorAll(s));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const icons = {
    dashboard:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    bookings:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18m-13 5h3m3 0h3"/>',
    customers:'<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2M17 5a3 3 0 0 1 0 6m2 9v-2a5 5 0 0 0-3-4.6"/>',
    vehicles:'<path d="m5 11 2-5h10l2 5M4 11h16l1 4v4h-3v-2H6v2H3v-4l1-4Z"/><path d="M7 14h2m6 0h2"/>',
    services:'<path d="m14 7 3 3-7 7-3-3 7-7Zm3-4a4 4 0 0 0-4 5L5 16l3 3 8-8a4 4 0 0 0 5-4l-3 2-3-3 2-3Z"/>',
    spare_parts:'<path d="m12 2 9 5-9 5-9-5 9-5Zm-9 5v10l9 5 9-5V7M12 12v10"/>',
    invoices:'<path d="M5 3h14v18l-3-2-4 2-4-2-3 2V3Zm4 5h6m-6 4h6"/>'
  };
  const icon = (path) => `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" aria-hidden="true">${path}</svg>`;
  $$('.nav-link').forEach((link, i) => {
    const id = i === 0 ? 'dashboard' : new URL(link.href).searchParams.get('page');
    if (icons[id] && $('.nav-icon',link)) $('.nav-icon',link).innerHTML = icon(icons[id]);
  });
  // Tactile ripples on all interactive buttons and action links.
  document.addEventListener('pointerdown', e => {
    if (reduceMotion || e.button !== 0) return;
    const target = e.target.closest('.btn,.nav-link,.quick-actions>a,.icon-btn,.search-form button,.top-search-trigger,.password-toggle,.mobile-menu,.command-item');
    if (!target || target.disabled) return;
    const rect = target.getBoundingClientRect();
    const diameter = Math.max(rect.width,rect.height);
    const circle = document.createElement('span');
    circle.className = 'ripple-circle';
    circle.style.cssText = `width:${diameter}px;height:${diameter}px;left:${e.clientX-rect.left-diameter/2}px;top:${e.clientY-rect.top-diameter/2}px`;
    target.appendChild(circle);
    circle.addEventListener('animationend', () => circle.remove(), {once:true});
  });
  // Password visibility toggle on login.
  const toggle = $('[data-password-toggle]');
  if (toggle) toggle.addEventListener('click', () => {
    const input = $('#password'); if (!input) return;
    const shown = input.type === 'password';
    input.type = shown ? 'text' : 'password';
    toggle.setAttribute('aria-pressed', String(shown));
    toggle.setAttribute('aria-label', shown ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi');
    $('[data-eye]', toggle).textContent = shown ? '◌' : '◉';
    input.focus({preventScroll:true});
  });
  // Mobile navigation overlay.
  const sidebar = $('#sidebar'), backdrop = $('#sidebarBackdrop'), menuToggle = $('[data-menu-toggle]');
  const setMenu = open => {
    if (!sidebar || !backdrop) return;
    sidebar.classList.toggle('open', open); backdrop.classList.toggle('visible', open);
    menuToggle?.setAttribute('aria-expanded', String(open));
    document.body.style.overflow = open ? 'hidden' : '';
  };
  menuToggle?.addEventListener('click', () => setMenu(!sidebar.classList.contains('open')));
  backdrop?.addEventListener('click', () => setMenu(false));
  window.addEventListener('resize', () => {if (innerWidth > 950) setMenu(false);});
  // Command palette / Ctrl+K: fast access to all real application pages.
  const sections = [
    ['Dashboard','Ringkasan operasional','index.php','dashboard'],
    ['Booking Servis','Jadwal servis pelanggan','index.php?page=bookings','bookings'],
    ['Pelanggan','Database pelanggan','index.php?page=customers','customers'],
    ['Kendaraan','Daftar kendaraan','index.php?page=vehicles','vehicles'],
    ['Layanan Servis','Katalog dan tarif jasa','index.php?page=services','services'],
    ['Suku Cadang','Persediaan barang','index.php?page=spare_parts','spare_parts'],
    ['Tagihan','Invoice dan pembayaran','index.php?page=invoices','invoices']
  ];
  let palette = null;
  const closePalette = () => {if(palette){palette.remove();palette=null;}};
  const openPalette = () => {
    if (palette) return;
    palette = document.createElement('div'); palette.className='command-backdrop';
    palette.innerHTML = '<div class="command-panel" role="dialog" aria-modal="true" aria-label="Navigasi cepat"><div class="command-search"><span>⌕</span><input type="search" aria-label="Cari menu" placeholder="Cari menu atau halaman..."><kbd>ESC</kbd></div><div class="command-list"></div><div class="command-footer">↑ ↓ pilih menu · Enter buka · Esc tutup</div></div>';
    document.body.appendChild(palette);
    palette.addEventListener('click', e => {if(e.target === palette)closePalette();});
    const search=$('input',palette), list=$('.command-list',palette);
    let active=0, visible=[];
    const render=()=>{
      const q=search.value.toLowerCase().trim();
      visible=sections.filter(x=>(x[0]+' '+x[1]).toLowerCase().includes(q));
      list.replaceChildren();
      if(!visible.length){const div=document.createElement('div');div.className='command-empty';div.textContent='Tidak ada menu yang cocok.';list.appendChild(div);return;}
      visible.forEach((item,i)=>{
        const a=document.createElement('a');a.className='command-item';a.href=item[2];
        const mark=document.createElement('span');mark.className='cmd-icon';mark.innerHTML=icon(icons[item[3]]);
        const content=document.createElement('span'),title=document.createElement('strong'),sub=document.createElement('small');
        title.textContent=item[0];sub.textContent=item[1];content.append(title,sub);
        const arrow=document.createElement('span');arrow.className='cmd-arrow';arrow.textContent='↗';
        a.append(mark,content,arrow);a.addEventListener('mouseenter',()=>active=i);list.appendChild(a);
      });active=0;
    };
    search.addEventListener('input',render);
    search.addEventListener('keydown',e=>{
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();active=(active+(e.key==='ArrowDown'?1:-1)+visible.length)%Math.max(1,visible.length);$$('.command-item',list)[active]?.focus();}
      if(e.key==='Enter'&&visible.length){window.location.href=visible[active][2];}
    });
    list.addEventListener('keydown',e=>{
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();active=(active+(e.key==='ArrowDown'?1:-1)+visible.length)%visible.length;$$('.command-item',list)[active]?.focus();}
    });
    render();search.focus();
  };
  $('[data-command-trigger]')?.addEventListener('click',openPalette);
  document.addEventListener('keydown',e=>{
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'&&$('.app-shell')){e.preventDefault();palette?closePalette():openPalette();}
    if(e.key==='Escape'){closePalette();setMenu(false);}
  });
  // Custom accessible confirmation for destructive actions.
  let confirmOpen=false;
  $$('form[onsubmit*="confirm("]').forEach(form=>{
    form.removeAttribute('onsubmit');
    form.addEventListener('submit', e=>{
      e.preventDefault();if(confirmOpen)return;
      confirmOpen=true;
      const isDelete=$('input[name="action"]',form)?.value==='delete';
      const wrap=document.createElement('div');wrap.className='confirm-backdrop';
      const dialog=document.createElement('div');dialog.className='confirm-panel';dialog.setAttribute('role','alertdialog');dialog.setAttribute('aria-modal','true');
      const symbol=document.createElement('div');symbol.className='confirm-symbol';symbol.textContent=isDelete?'!':'▧';
      const title=document.createElement('h3');title.textContent=isDelete?'Hapus data ini?':'Buat tagihan baru?';
      const desc=document.createElement('p');desc.textContent=isDelete?'Data yang dihapus tidak bisa dikembalikan. Pastikan Anda sudah memilih data yang tepat.':'Tagihan akan dibuat berdasarkan biaya jasa dan suku cadang pada perintah kerja ini.';
      const actions=document.createElement('div');actions.className='confirm-actions';
      const cancel=document.createElement('button');cancel.type='button';cancel.className='btn btn-ghost';cancel.textContent='Batal';
      const ok=document.createElement('button');ok.type='button';ok.className='btn btn-primary';ok.textContent=isDelete?'Ya, hapus data':'Buat tagihan';
      const close=()=>{wrap.remove();confirmOpen=false;};
      cancel.addEventListener('click',close);wrap.addEventListener('click',ev=>{if(ev.target===wrap)close();});
      ok.addEventListener('click',()=>{ok.classList.add('is-loading');ok.disabled=true;form.submit();});
      actions.append(cancel,ok);dialog.append(symbol,title,desc,actions);wrap.appendChild(dialog);document.body.appendChild(wrap);cancel.focus();
      const onKey=ev=>{if(ev.key==='Escape'){close();document.removeEventListener('keydown',onKey);}};
      document.addEventListener('keydown',onKey);
    });
  });
  // Feedback for saving / login, after native form validation has succeeded.
  $$('form.data-form,form.auth-form').forEach(form=>form.addEventListener('submit',()=>{
    const btn=$('button[type="submit"]',form);if(!btn)return;
    btn.classList.add('is-loading');btn.setAttribute('aria-busy','true');
  }));
  // Smooth count-up on dashboard stats.
  if(!reduceMotion && 'IntersectionObserver' in window){
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{
      if(!entry.isIntersecting)return;observer.unobserve(entry.target);
      const el=entry.target, n=Number(el.textContent.replace(/\D/g,''));
      if(!Number.isFinite(n)||n<=0)return;
      const start=performance.now(),duration=800,format=new Intl.NumberFormat('id-ID');
      const step=now=>{const t=Math.min((now-start)/duration,1);el.textContent=format.format(Math.round(n*(1-Math.pow(1-t,3))));if(t<1)requestAnimationFrame(step);};
      requestAnimationFrame(step);
    }),{threshold:.25});
    $$('.stat-number').forEach(el=>observer.observe(el));
  }
  // Toast for successful server feedback (alert stays readable in DOM for accessibility).
  const alert=$('.app-shell .alert-success');
  if(alert){
    const stack=document.createElement('div');stack.className='toast-stack';
    const toast=document.createElement('div');toast.className='toast-item success';toast.setAttribute('role','status');
    const msg=document.createElement('span');msg.textContent='✓  '+alert.textContent.trim();
    const dismiss=document.createElement('button');dismiss.type='button';dismiss.textContent='×';dismiss.setAttribute('aria-label','Tutup notifikasi');
    toast.append(msg,dismiss);stack.appendChild(toast);document.body.appendChild(stack);
    const remove=()=>stack.remove();dismiss.addEventListener('click',remove);setTimeout(remove,5500);
  }
})();
