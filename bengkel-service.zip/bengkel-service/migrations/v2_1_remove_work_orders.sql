-- BengkelPro v2.1: jalankan HANYA untuk database yang dibuat dari versi 1 / 2.0.
-- Backup database terlebih dahulu. Data invoice dan perintah kerja lama TIDAK dihapus.
-- Mengizinkan tagihan baru dibuat tanpa tautan ke perintah kerja lama.
USE bengkel_service;
ALTER TABLE invoices MODIFY COLUMN work_order_id BIGINT UNSIGNED NULL DEFAULT NULL;
-- Tabel work_orders dan relasi lama tetap ada sebagai arsip historis.
-- Untuk instalasi baru, impor database.sql v2.1 (tanpa tabel work_orders).
